#!/bin/bash
java -jar Scrapper_autoamtion-0.0.1-SNAPSHOT-jar-with-dependencies.jar